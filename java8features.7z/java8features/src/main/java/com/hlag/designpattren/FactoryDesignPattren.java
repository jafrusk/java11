package com.hlag.designpattren;

interface Shipments {
	void deliver();
}

class AirShipment implements Shipments {

	@Override
	public void deliver() {
		System.out.println("Delivering by air.");
	}
}

class SeaShipment implements Shipments {
	@Override
	public void deliver() {
		System.out.println("Delivering by sea.");
	}
}

class LandShipment implements Shipments {
	@Override
	public void deliver() {
		System.out.println("Delivering by land.");
	}
}

//Step 3: Create a ShipmentFactory class
class ShipmentFactory {
// Factory method to create Shipment objects
	public static Shipments createShipment(String shipmentType) {
		switch (shipmentType.toLowerCase()) {
		case "air":
			return new AirShipment();
		case "sea":
			return new SeaShipment();
		case "land":
			return new LandShipment();
		default:
			throw new IllegalArgumentException("Invalid shipment type: " + shipmentType);
		}
	}
}

public class FactoryDesignPattren {

	public static void main(String[] args) {
		// Create different shipments using the factory
		Shipments airShipment = ShipmentFactory.createShipment("air");
		Shipments seaShipment = ShipmentFactory.createShipment("sea");
		Shipments landShipment = ShipmentFactory.createShipment("land");

		// Deliver the shipments
		airShipment.deliver();
		seaShipment.deliver();
		landShipment.deliver();

	}

}
