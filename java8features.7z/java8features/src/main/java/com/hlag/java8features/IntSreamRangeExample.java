package com.hlag.java8features;

import java.time.Instant;
import java.util.List;
import java.util.stream.IntStream;

public class IntSreamRangeExample {

	public static void main(String[] args) {
		
		List<Integer> numbers = IntStream.range(1, 10_000_000).boxed().toList();
		Instant start = Instant.now() ;
		Long sequentialSum = numbers.parallelStream().mapToLong(n->n*n).sum();
		Instant end = Instant.now() ;
		System.out.println("sequentialSum : "+ sequentialSum +"Diffrence in time "+ (start.toEpochMilli()-end.toEpochMilli()) );

	}

}
