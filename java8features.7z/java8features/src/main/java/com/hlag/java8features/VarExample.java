package com.hlag.java8features;

public class VarExample {

	public static void main(String[] args) {
		
		String str ="Hello, World!";
		//isBlank
		System.out.println("String is blank : "+str.isBlank());
		//lines
		str.lines().forEach(System.out::println);
		//strip
		System.out.println("Stripped String : "+ str.strip());
	}

}
