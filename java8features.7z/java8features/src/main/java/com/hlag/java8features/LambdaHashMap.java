package com.hlag.java8features;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class LambdaHashMap {

	public static void main(String[] args) {
		demo();  
		
		Function<String, Integer>  function = (s) ->s.length();
		Function<Integer, Integer>  func1 = (x) ->x*2;
		
		int result = function.andThen(func1).apply("Jafru");
		
		System.out.println(result);
	}

	public static void demo() {
		Map<String, Integer> map = new HashMap<>();
		map.put("A", 10);
		map.put("B", 20);
		map.put("C", 30);
		map.put("D", 40);
		map.put("E", 50);
		map.put("F", 60);

		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			System.out.println("Key : " + entry.getKey() + " , value : " + entry.getValue());
		}
		System.out.println("With Lambda ----");
		map.forEach((k , v ) -> System.out.println("Key : " + k+ " , value : " + v));
	}

}


