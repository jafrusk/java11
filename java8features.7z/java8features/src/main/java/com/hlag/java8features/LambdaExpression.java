package com.hlag.java8features;

public class LambdaExpression {

	public static void main(String[] args) {
		
//		I5 i5 = new I5Impl();
//		i5.test();
//		i5.test2();
		demo((a,b) -> a+b);
		
		I5 i = () -> System.out.println("I");
		i.test2();
		i.test();
		
		I5 i5 = new I5() {
			
			@Override
			public void test() {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void test2() {
				System.out.println("Test from override");
			}
		};
		i5.test2();

	}
	public static void demo(Iops iops) {
		System.out.println(iops.add(20, 20));
	}
}


	class I5Impl implements I5{

		@Override
		public void test() {
			System.out.println("I am from test");
		}
		@Override
		public void test2() {
			System.out.println("Hello from override test2");
		}
		
		
	}
	
	
	@FunctionalInterface
	interface I5{
		public void test();
		public default  void test2() {
			System.out.println("Hello from test2");
		}
	}
	
	
	@FunctionalInterface
	interface Iops {
		public int add(int a , int b);
		
	}
	


