package com.hlag.java8features;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeRepo {
	
	List<Employee> employees = new ArrayList<>();
	
	public void saveEmployee(Employee employee) {
		 employees.add(employee);
	}
	
	public List<Employee> getEmployeeBySalary(){
		return employees.stream().filter(e->(e.getSalary()>50000.0)).toList();
		
	}
	public Map<String, Double> getEmployeeNameAndSalary(){
		return employees.stream().filter(e->(e.getSalary()>50000.0)).collect(Collectors.toMap(e->e.getName(), e->e.getSalary()));
		
	}
	
	public double getSalary() {
		return employees.stream().filter(e->(e.getSalary()>50000.0)).map(e->e.getSalary()).reduce(0.0,Double::sum);
		
	}

}
