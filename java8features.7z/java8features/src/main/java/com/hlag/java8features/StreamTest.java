package com.hlag.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamTest {

	public static void main(String[] args) {
		
		List<String> words = Arrays.asList("apple", "banana", "cherry","date");
		//List<String> result = new ArrayList<>();
		Long startTime = System.currentTimeMillis();
//		for (String word : words) {
//			if(word.length()>5) {
//				result.add(word.toUpperCase());
//			}
//			
//		}
		List<String> result = words.stream().filter(w->w.length()>5).map(e->e.toUpperCase()).collect(Collectors.toList());
		result.stream().forEach(w -> System.out.println(w));
		result.forEach(w->System.out.println(w));
		Long endTime = System.currentTimeMillis();
		System.out.println("startTime : "+ startTime );
		System.out.println("endTime : "+ endTime );
		System.out.println("Diffence : "+ (startTime- endTime) );
		System.out.println("result : "+result);

	}

}
