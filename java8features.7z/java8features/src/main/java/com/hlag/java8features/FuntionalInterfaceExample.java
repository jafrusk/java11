package com.hlag.java8features;

public class FuntionalInterfaceExample {

	public static void main(String[] args) {

		CargoProcessor processor = cargo -> System.out.println("Processing cargo: " + cargo);
		processor.process("Electronics");

	}

}

@FunctionalInterface
interface CargoProcessor {
	void process(String cargo);
}
