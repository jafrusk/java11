package com.hlag.java8features;

import java.util.Arrays;
import java.util.List;

public class StreamApiExample {

	public static void main(String[] args) {
		 List<String> cargoList = Arrays.asList("Electronics", "Furniture", "Clothing", "Food");
	        
	        // Creating a stream and filtering items
	        long count = cargoList.stream()
	                              .filter(cargo -> cargo.startsWith("E"))
	                              .count();
	        
	        System.out.println("Count of cargo items starting with 'E': " + count);


	}

}
