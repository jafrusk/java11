package com.hlag.java8features;

public class Customer {
	String region;
	String demographic;
	String quantity;
	public Customer(String region, String demographic, String quantity) {
		super();
		this.region = region;
		this.demographic = demographic;
		this.quantity = quantity;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDemographic() {
		return demographic;
	}
	public void setDemographic(String demographic) {
		this.demographic = demographic;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	

}
