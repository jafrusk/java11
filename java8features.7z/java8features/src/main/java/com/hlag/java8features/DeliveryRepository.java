package com.hlag.java8features;

import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

public interface DeliveryRepository {
	

    // Save a new delivery
    void save(Delivery delivery);

    // Find a delivery by its ID
    Optional<Delivery> findById(String deliveryId);

    // Get all deliveries
    List<Delivery> findAll();

    // Update an existing delivery
    void update(Delivery delivery);

    // Delete a delivery by its ID
    void deleteById(String deliveryId);

    // Get deliveries that are completed
    List<Delivery> findCompletedDeliveries();
    
    // Get deliveries that are completed
    List<Delivery> getDeliveriesByRevenue();
    
    //update the deliverySatuts
    
    List<Delivery> updateDeliverySatuts(String deliveryId);
    
    void deleteByCompleted(String deliveryId);
    
    double calculateTotalRevenue();
    double calculateAvgDeliveryTime() throws CustomException;
    List<Delivery> findTopDeliveries();

}
