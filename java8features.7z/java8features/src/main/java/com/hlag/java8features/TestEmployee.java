package com.hlag.java8features;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.swing.border.EmptyBorder;

public class TestEmployee {

	public static void main(String[] args) {
		EmployeeRepo employeeRepo = new EmployeeRepo();
		
		List<Employee> employees = Arrays.asList(
				new Employee("Jafru", 500000, "Development", 20),
				new Employee("Sk", 111110, "Testting", 30),
				new Employee("Jaf", 1121110, "Support", 40));
	
		double secondHihgestSalary = employees.stream().map(m->m.getSalary()).distinct().sorted().skip(1).findFirst().get();
		System.out.println("secondHihgestSalary" + secondHihgestSalary);
		
		for (Employee employee : employees) {
			employeeRepo.saveEmployee(employee);
		} 
		Map<String, Double> employeee =	employeeRepo.getEmployeeNameAndSalary();
		System.out.println("Employee : " + employeee);
		
		double salary = employeeRepo.getSalary();
		System.out.println("salary : " + salary);
	}

}
