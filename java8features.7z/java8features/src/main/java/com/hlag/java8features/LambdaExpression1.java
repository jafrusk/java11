package com.hlag.java8features;

import java.util.function.Function;

public class LambdaExpression1 {

	public static void main(String[] args) {

		calculation cal = (a) -> a % 7 == 0;
		boolean result = cal.validateNumber(8);
		System.out.println("result = " + result);
		
		Function<Integer , Boolean> function = (n)->  n%7==0;
		System.out.println(function.apply(7));
	}

	@FunctionalInterface
	interface calculation {
		public boolean validateNumber(int a);
	}

}
