package com.hlag.java8features;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class DeliveryRepositoryImpl implements DeliveryRepository {
    
    private List<Delivery> deliveries = new ArrayList<>();
    
    // Save a new delivery
    @Override
    public void save(Delivery delivery) {
        deliveries.add(delivery);
    }

    // Find a delivery by its ID
    @Override
    public Optional<Delivery> findById(String deliveryId) {
        return deliveries.stream()
                         .filter(delivery -> delivery.getDeliveryId().equals(deliveryId))
                         .findFirst();
    }

    // Get all deliveries
    @Override
    public List<Delivery> findAll() {
        return new ArrayList<>(deliveries);
    }

    // Update an existing delivery
    @Override
    public void update(Delivery delivery) {
        Optional<Delivery> existingDelivery = findById(delivery.getDeliveryId());
        if (existingDelivery.isPresent()) {
            deliveries.remove(existingDelivery.get());
            deliveries.add(delivery);
        }
    }

    // Delete a delivery by its ID
    @Override
    public void deleteById(String deliveryId) {
        deliveries.removeIf(delivery -> delivery.getDeliveryId().equals(deliveryId));
    }

    // Get deliveries that are completed
    @Override
    public List<Delivery> findCompletedDeliveries() {
//        List<Delivery> completedDeliveries = new ArrayList<>();
//        for (Delivery delivery : deliveries) {
//            if (delivery.isCompleted()) {
//                completedDeliveries.add(delivery);
//            }
//        }
        List<Delivery> completedDeliveries =  deliveries.stream().filter(d -> d.isCompleted()).collect(Collectors.toList());
        return completedDeliveries;
    }

 // Get deliveries that are revenue exceeds
	@Override
	public List<Delivery> getDeliveriesByRevenue() {
		 List<Delivery> deliveryList =  deliveries.stream().filter(d ->  d.getRevenue()>50).collect(Collectors.toList());
	        return deliveryList;
	}

	// Update the  delivery status
	@Override
	public List<Delivery> updateDeliverySatuts(String deliveryId) {
		List<Delivery> deliveryList = deliveries.stream().map(d -> {
			if (deliveryId.equals(d.getDeliveryId()) && !d.isCompleted()) {
				d.setCompleted(true);
			}
			return d;
		}).collect(Collectors.toList());
		return deliveryList;
	}

	// delete the records who's delivery status true
	@Override
	public void deleteByCompleted(String deliveryId) {
		List<Delivery> deliveryList = deliveries.stream().filter(d-> deliveryId.equals(d.getDeliveryId()) &&d.isCompleted()).collect(Collectors.toList());
		System.out.println("deliveryList from repo : " + deliveryList);
		
		deliveryList.removeAll(deliveryList);
	}

	@Override
	public double calculateTotalRevenue() {
		return	deliveries.stream().mapToDouble(d ->d.getRevenue()).sum();
	}

	@Override
	public double calculateAvgDeliveryTime() throws CustomException {
		return	deliveries.stream().mapToDouble(d ->d.getDoubledeliveryTimeInHours()).average().orElseThrow(()-> new CustomException("Data not found"));
	}

	@Override
	public List<Delivery> findTopDeliveries() {
		return	deliveries.stream().filter(d -> d.isCompleted()).sorted((a,b) -> Double.compare(a.getDoubledeliveryTimeInHours(), b.getDoubledeliveryTimeInHours())).limit(2).collect(Collectors.toList());
	}
    
    
}