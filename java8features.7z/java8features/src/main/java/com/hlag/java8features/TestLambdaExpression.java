package com.hlag.java8features;

public class TestLambdaExpression {

	public static void main(String[] args) {

		Greeter greeter = (m) -> m;
		System.out.println(greeter.greet("Hello, Alice!"));

		NumberCheck numberCheck = (n) -> n % 2 == 0;
		System.out.println(numberCheck.check(8));

		MathOperation mathOperation = (a, b) -> {
			System.out.println(a + b);
			System.out.println(a - b);
			System.out.println(a * b);
		};
		mathOperation.check(10, 20);
		
		StringManipulator manipulator = (i)->i.toUpperCase();
		System.out.println(manipulator.greet("Jafru"));

	}
	
	
}

@FunctionalInterface
interface Greeter {
	public String greet(String msg);
}
@FunctionalInterface
interface StringManipulator {
	public String greet(String input);
}

@FunctionalInterface
interface NumberCheck {
	public Boolean check(int number);
}

@FunctionalInterface
interface MathOperation {
	public void check(int a, int b);
}
