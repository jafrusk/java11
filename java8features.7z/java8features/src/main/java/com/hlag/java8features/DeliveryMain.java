package com.hlag.java8features;

import java.util.Arrays;
import java.util.List;

public class DeliveryMain {

	public static void main(String[] args) {
		
		DeliveryRepositoryImpl deliveryRepositoryImpl = new DeliveryRepositoryImpl();
		
		List<Delivery> deliveries = Arrays.asList(
				new Delivery("D1", true, 1.5, 10.0, 50.0),
				new Delivery("D2", false, 2.0, 15.0, 70.0),
				new Delivery("D3", true, 4.5, 10.0, 40.0),
				new Delivery("D4", true, 1.5, 10.0, 90.0),
				new Delivery("D5", false, 3.5, 10.0, 20.0),
				new Delivery("D6", true, 2.5, 10.0, 80.0));
		for (Delivery delivery : deliveries) {
			deliveryRepositoryImpl.save(delivery);
			//List<Delivery> deliveries2 =  deliveryRepositoryImpl.updateDeliverySatuts(delivery.getDeliveryId());
			//System.out.println("Deleivery by revenue : "+ deliveries2);
//			if(delivery.getDeliveryId()!=null) {
//			deliveryRepositoryImpl.deleteByCompleted(delivery.getDeliveryId());
//			System.out.println("Deleted sucessfully : " + delivery.getDeliveryId());
//			}
			
		}
		List<Delivery> deliver1 =	deliveryRepositoryImpl.findTopDeliveries();
		System.out.println("Top delivery"+deliver1);
		double totalRevenue = deliveryRepositoryImpl.calculateTotalRevenue();
		System.out.println("totalRevenue : " + totalRevenue);
		double avgDeliveryTime;
		try {
			avgDeliveryTime = deliveryRepositoryImpl.calculateAvgDeliveryTime();
			System.out.println("avg Delivery Time : " + avgDeliveryTime);
		} catch (CustomException e) {
			e.getMessage();
		}
		List<Delivery> deliveries3 = deliveryRepositoryImpl.getDeliveriesByRevenue();
		//System.out.println("Deleivery by revenue : "+ deliveries3);
	}

}
