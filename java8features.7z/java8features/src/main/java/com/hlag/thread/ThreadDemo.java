package com.hlag.thread;

import java.util.stream.IntStream;

public class ThreadDemo {

	public static void main(String[] args) throws InterruptedException {

		Runnable runnable = () -> {
			IntStream.range(1, 10).forEach(n -> {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Current : " + Thread.currentThread().getName());

			});
		};

		Thread thread = new Thread(runnable);
		thread.setName("Thread 1");
		thread.setPriority(1);
		thread.join();
		thread.start();
		Thread thread2 = new Thread(runnable);
		thread.setName("Thread 2");
		thread2.setPriority(2);
		thread2.join();
		thread2.start();
		Thread thread3 = new Thread(runnable);
		thread.setName("Thread 3");
		thread3.setPriority(3);
		thread3.join();
		thread3.start();
		Thread.getAllStackTraces().forEach((k, v) -> {
			if ("main".equals(k.getThreadGroup().getName())) {
				System.out.println(k);
			}
		});
	}

}
