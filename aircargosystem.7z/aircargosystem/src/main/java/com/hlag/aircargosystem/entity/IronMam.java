package com.hlag.aircargosystem.entity;

public class IronMam extends SuperHero implements Flyable{

	@Override
	public void fly() {
		System.out.println("Iron man can fly");
		
	}
	
	public void display() {
		System.out.println("Iron man");
		
	}

	@Override
	public void power() {
		System.out.println("Iron man Power");
		
	}

	


}
