package com.hlag.aircargosystem.entity;

public abstract class SuperHero {
	
	public abstract void power();

}
