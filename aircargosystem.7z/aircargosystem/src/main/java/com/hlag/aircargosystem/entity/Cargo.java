package com.hlag.aircargosystem.entity;

public class Cargo extends CargoItem implements Trackable {
	
    // Instance Variables
    private String cargoId;
    private String description;
    protected int weight;
    private int distance;
    private double price;
  
    public Cargo(String cargoId, String description, int weight, int distance) {
		super(cargoId);
		this.cargoId = cargoId;
		this.description = description;
		setWeight(weight);
		this.distance = distance;
		calShippingCost();
	}
    
	public String getCargoId() {
		return cargoId;
	}
	public void setCargoId(String cargoId) {
		this.cargoId = cargoId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		if (weight > 0) {
			this.weight = weight;
		} else {
			throw new IllegalArgumentException("Weight must be positive.");
		}
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	// Method to display cargo details
    public void displayDetails() {
        System.out.println("Cargo ID: " + cargoId + ", Description: " + description + ", Weight: " + weight +", Distance: "+ distance + ", price: "+ price);
    }
   
	//calculate shipping cost based on weight and distance
	public double calShippingCost() {
		if (this.distance <= 100 || this.weight <= 100) {
			this.price = 0;
		} else if (this.distance > 100 || this.weight > 100) {
			this.price = 1000;
		} else if (this.distance <= 500 || this.weight <= 500) {
			this.price = 5000;
		} else {
			this.price = 10000;
		}
		return price;
	}
	
//	method overloading (compile-time polymorphism)
	public double calculateShippingCost(double weight) {
	    return weight * 2.5; // Cost per kg
	}

	public double calculateShippingCost(double weight, double distance) {
	    return weight * distance * 0.05; // Cost based on distance
	}
	
	@Override
	public void trackCargo() {
		System.out.println("Tracking cargo ID: " + cargoId);
		
	}
	@Override
	public double calculateShippingCost() {
		return calShippingCost();
	}


}

