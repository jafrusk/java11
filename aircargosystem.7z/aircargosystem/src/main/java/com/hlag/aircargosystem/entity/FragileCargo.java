package com.hlag.aircargosystem.entity;

public class FragileCargo extends Cargo{
	private String handlingInstructions;
	
	public FragileCargo(String cargoId, String description, int weight, int distance, String handlingInstructions) {
		super(cargoId, description, weight, distance);
		this.handlingInstructions = handlingInstructions;
	}

	public void displayHandlingInstructions() {
		System.out.println("Handling Instructions: " + handlingInstructions);
	}

	@Override
	public void displayDetails() {
	    super.displayDetails();
	    System.out.println("This cargo is fragile. " + handlingInstructions);
	}
	
	@Override
	public double calculateShippingCost(double weight, double distance) {
	    return weight * distance * 0.05; // Cost based on distance
	}


	

}
