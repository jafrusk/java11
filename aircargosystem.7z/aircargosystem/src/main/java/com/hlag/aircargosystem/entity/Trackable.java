package com.hlag.aircargosystem.entity;

public interface Trackable {

	 void trackCargo();

}
