package com.hlag.aircargosystem.entity;

public abstract class CargoItem {
	
	protected String cargoId;

    public CargoItem(String cargoId) {
        this.cargoId = cargoId;
    }

    // Abstract method
    public abstract double calculateShippingCost();


}
