package com.hlag.aircargosystem;


import com.hlag.aircargosystem.entity.Cargo;
import com.hlag.aircargosystem.entity.Flyable;
import com.hlag.aircargosystem.entity.FragileCargo;
import com.hlag.aircargosystem.entity.IronMam;

public class App {
	
	 public static void fly(Flyable flyable) {
		 flyable.fly();
	    }
	public static void main(String[] args) {
		
		  Cargo cargo1 = new Cargo("C001", "Electronics", 101, 200);
		  cargo1.displayDetails(); cargo1.trackCargo(); FragileCargo fragileCargo = new
		  FragileCargo("C002", "Medicines", 80, 0,
		  "Handle with Care, Shake well before use"); fragileCargo.displayDetails();
		  
		  
		  Cargo cargo2 = new FragileCargo("C002", "Glassware", 101, 200,
		  "Handle with care."); cargo2.displayDetails();
		 
//			Flyable flyable = new IronMam();
//			flyable.fly();
//			fly(new IronMam());
//			IronMam ironMam = new IronMam();
//			ironMam.fly();

	}

}
