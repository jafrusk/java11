package com.hlag.aircargosystem.entity;

public interface Flyable {

	public void fly();
}
