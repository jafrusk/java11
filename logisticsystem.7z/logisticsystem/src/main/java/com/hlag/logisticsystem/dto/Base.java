package com.hlag.logisticsystem.dto;

public class Base {

}
