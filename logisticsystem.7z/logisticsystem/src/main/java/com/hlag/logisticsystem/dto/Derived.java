package com.hlag.logisticsystem.dto;

public class Derived extends Base {

}
