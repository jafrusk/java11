package com.hlag.logisticsystem.dto;

public class CargoItem {

	private int weight;
	private int dimensions;
	private String type;

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getDimensions() {
		return dimensions;
	}

	public void setDimensions(int dimensions) {
		this.dimensions = dimensions;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void calShipingCostByWeight(int cargoWeight) {
		cargoWeight = this.weight;
		if (cargoWeight <= 100) {
			System.out.println("Standard shipping.");
		} else if (cargoWeight <= 500) {
			System.out.println("Expedited shipping.");
		} else {
			System.out.println("Heavy cargo, requires special arrangements.");
		}

	}

}
