package com.hlag.logisticsystem;

import com.hlag.logisticsystem.dto.CargoItem;
import com.hlag.logisticsystem.dto.Package;

public class App {

	public static void main(String[] args) {

		Package package1 = Package.getIPackage();
		Package package2 = Package.getIPackage();
		System.out.println(package1.equals(package2));
		System.out.println("pack1 : " + package1.hashCode());
		System.out.println("pack2 : " + package2.hashCode());
		
		CargoItem cargoItem = new CargoItem();
		cargoItem.calShipingCostByWeight(100);
	}
}
