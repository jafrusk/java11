package com.hlag.inventorymanagementsystem.service;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;

public interface InventoryService {
	
	public Product addProduct(Product product);

	public Optional<Product> findByProductId(String productId);
	
	public List<Product> findAllProducts(Optional<String> sortByNameOrPrice);

	public Product updateProduct(String productId, Product product);

	public void deleteByProductId(String productId);

}
