package com.hlag.inventorymanagementsystem.service;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.repo.InventoryRepoImpl;

public class InventoryServiceImpl implements InventoryService {

	private static InventoryServiceImpl inventoryServiceImpl;

	private InventoryServiceImpl() {

	}

	public static InventoryServiceImpl getInstance() {
		if (inventoryServiceImpl == null) {
			inventoryServiceImpl = new InventoryServiceImpl();
		}
		return inventoryServiceImpl;
	}

	private InventoryRepoImpl inventoryRepoImpl = InventoryRepoImpl.getInstance();

	@Override
	public Product addProduct(Product product) {
		return inventoryRepoImpl.addProduct(product);
	}

	@Override
	public Optional<Product> findByProductId(String productId) {
		return inventoryRepoImpl.findByProductId(productId);
	}

	@Override
	public List<Product> findAllProducts(Optional<String> sortByNameOrPrice) {
		return inventoryRepoImpl.findAllProducts(sortByNameOrPrice);
	}

	@Override
	public Product updateProduct(String productId, Product product) {
		return inventoryRepoImpl.updateProduct(productId, product);
	}

	@Override
	public void deleteByProductId(String productId) {
		inventoryRepoImpl.deleteByProductId(productId);
	}

}
