package com.hlag.inventorymanagementsystem.repo;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;

public interface InventoryRepo {

	public Product addProduct(Product product);

	public Optional<Product> findByProductId(String productId);
	
	public List<Product> findAllProducts(Optional<String> sortByNameOrPrice);

	public Product updateProduct(String productId, Product product);

	public void deleteByProductId(String productId);

}
