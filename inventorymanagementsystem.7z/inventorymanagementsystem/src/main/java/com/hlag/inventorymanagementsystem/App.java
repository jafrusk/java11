package com.hlag.inventorymanagementsystem;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.exceptions.CustomException;
import com.hlag.inventorymanagementsystem.service.InventoryServiceImpl;

public class App {

	public static void main(String[] args) {
		InventoryServiceImpl inventoryServiceImpl = InventoryServiceImpl.getInstance();
		String operation = "GetById";
		switch (operation) {
		case "Create": // Add Products
			getProducts(inventoryServiceImpl);
			break;
		case "GetAll": // View all products
			getProducts(inventoryServiceImpl);
			Optional<String> sortBy = Optional.of("name"); // Change to "price" or empty for no sorting
			System.out.println("Display all products:");
			List<Product> productList = inventoryServiceImpl.findAllProducts(sortBy);
			System.out.println("Product List :" + productList);
			break;
		case "GetById": // Find a product by ID
			Product getProduct = getProductById(inventoryServiceImpl);
			Optional<Product> optionalProduct = inventoryServiceImpl.findByProductId(getProduct.getProductId().toString());
			System.out.println("Get product by id : " + optionalProduct);
			break;
		case "Update": // Update a product
			try {
				Product newProduct = new Product("Tomato", "For Curry", 2344.0, 1);
				Product createProduct = inventoryServiceImpl.addProduct(newProduct);
				String productId = createProduct.getProductId().toString();
				Product updatedProduct = new Product("Beans", "Green Beans", 1125.0, 10);
				Product result = inventoryServiceImpl.updateProduct(productId, updatedProduct);
				if (result != null) {
					System.out.println("Product updated: " + result);
				} else {
					System.out.println("Product ID not found.");
				}
			} catch (CustomException e) {
				e.printStackTrace();
			}
			break;
		case "Delete": // Delete a product by ID
			Product product = getProductById(inventoryServiceImpl);
			String productId = product.getProductId().toString();
			inventoryServiceImpl.deleteByProductId(productId);
			System.out.println("Product was deleted");
			break;

		default:
			System.out.println("Invalid action.");
		}
	}

	private static Product getProductById(InventoryServiceImpl inventoryServiceImpl) {
		Product product = null;
		try {
			product = new Product("Beans", "Green Beans", 1500.0, 5);
		} catch (CustomException e) {
			e.printStackTrace();
		}
		Product getProduct = inventoryServiceImpl.addProduct(product);
		return getProduct;
	}

	private static void getProducts(InventoryServiceImpl inventoryServiceImpl) {
		try {
			Product product1 = new Product("Tomato", "For Curry", 2344.0, 1);
			Product product2 = new Product("Beans", "Green Beans", 1125.0, 10);
			Product product3 = new Product("Potato", "For Chips", 2375.0, 7);
			inventoryServiceImpl.addProduct(product1);
			inventoryServiceImpl.addProduct(product2);
			inventoryServiceImpl.addProduct(product3);
			System.out.println("Products added successfully.");
		} catch (CustomException e) {
			e.printStackTrace();
		}
	}

}
