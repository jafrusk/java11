package com.hlag.inventorymanagementsystem.repo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.hlag.inventorymanagementsystem.entity.Product;

public class InventoryRepoImpl implements InventoryRepo {

	private static InventoryRepoImpl inventoryRepoImpl;

	private InventoryRepoImpl() {

	}

	public static InventoryRepoImpl getInstance() {
		synchronized (InventoryRepoImpl.class) {
			if (inventoryRepoImpl == null) {
				inventoryRepoImpl = new InventoryRepoImpl();
			}
		}
		return inventoryRepoImpl;
	}

	private List<Product> products = new ArrayList<>();

	@Override
	public Product addProduct(Product product) {
		boolean productResult = products.add(product);
		if (productResult) {
			return product;
		}
		return null;
	}

	@Override
	public Optional<Product> findByProductId(String productId) {
		UUID id = UUID.fromString(productId);
		return products.stream().filter(p -> p.getProductId().equals(id)).findFirst();
	}

	@Override
	public List<Product> findAllProducts(Optional<String> sortByNameOrPrice) {
		if (products.isEmpty()) {
			System.out.println("No products available.");
		}
		List<Product> sortedProducts = new ArrayList<>(products);
		sortByNameOrPrice.ifPresent(criteria -> {
			switch (criteria.toLowerCase()) {
			case "price":
				sortedProducts.sort(Comparator.comparing(Product::getPrice));
				break;
			case "name":
				sortedProducts.sort(Comparator.comparing(Product::getName));
				break;
			default:
				break;
			}
		});
		return sortedProducts;
	}

	@Override
	public Product updateProduct(String productId, Product product) {
		return findByProductId(productId).map(existingProduct -> {
			products.set(products.indexOf(existingProduct), product);
			return product;
		}).orElse(null);
	}

	@Override
	public void deleteByProductId(String productId) {
		findByProductId(productId).map(exstingProduct->products.remove(exstingProduct));
	}
	
	/*
	 * public static void main(String[] args) {
	 * 
	 * Runnable runnable = () -> {
	 * 
	 * InventoryRepoImpl inventoryRepoImpl = getInstance();
	 * System.out.println("inventoryRepoImpl : "+ inventoryRepoImpl.hashCode()); };
	 * 
	 * Thread thread = new Thread(runnable); thread.setName("Thread 1");
	 * thread.setPriority(1); thread.start(); Thread thread2 = new Thread(runnable);
	 * thread2.setName("Thread 2"); thread2.setPriority(2); thread2.start(); Thread
	 * thread3 = new Thread(runnable); thread3.setName("Thread 3");
	 * thread3.setPriority(3); thread3.start(); //
	 * Thread.getAllStackTraces().forEach((k, v) -> { // if
	 * ("main".equals(k.getThreadGroup().getName())) { // System.out.println(k); //
	 * } // }); //
	 * 
	 * }
	 */

}
