package com.hlag.inventorymanagementsystem.entity;

import java.util.UUID;

import com.hlag.inventorymanagementsystem.exceptions.CustomException;

public class Product {

	private UUID productId;
	private String name;
	private String description;
	private Double price;
	private Integer quantity;

	public Product(String name, String description, Double price, Integer quantity) throws CustomException {
		this.productId = UUID.randomUUID();
		this.name = name;
		this.description = description;
		setPrice(price);
		setQuantity(quantity);
	}

	public UUID getProductId() {
		return productId;
	}

	public void setProductId(UUID productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) throws CustomException {
		if (price > 0) {
			this.price = price;
		} else {
			throw new CustomException("Price must be greater than 0.");
		}
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) throws CustomException {
		if (quantity > 0) {
			this.quantity = quantity;
		} else {
			throw new CustomException("Quantity must be greater than 0.");
		}
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", description=" + description + ", price="
				+ price + ", quantity=" + quantity + "]";
	}

}
